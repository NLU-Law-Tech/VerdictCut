# Cut the verdict
```
|-- undefined
    |-- LICENSE.txt
    |-- package-lock.json
    |-- push.sh
    |-- README.md
    |-- setup.py
    |-- build
    |   |-- bdist.win32
    |   |-- lib
    |       |-- VerdictCut
    |           |-- find_fact.py
    |           |-- find_justice.py
    |           |-- find_laws.py
    |           |-- find_maintext.py
    |           |-- find_roles.py
    |           |-- __init__.py
    |-- VerdictCut 
    |   |-- find_fact.py
    |   |-- find_justice.py
    |   |-- find_laws.py
    |   |-- find_maintext.py
    |   |-- find_roles.py
    |   |-- __init__.py
    |-- VerdictCut.egg-info
        |-- dependency_links.txt
        |-- PKG-INFO
        |-- SOURCES.txt
        |-- top_level.txt
```
